//
//  UserData.swift
//  SwiftUISample
//
//  Created by sohee on 2019/06/06.
//  Copyright © 2019 daybreak. All rights reserved.
//

import Foundation
