import UIKit

@UIApplicationMain
final class AppDelegate: UIResponder, UIApplicationDelegate {}
