struct SearchUserResponse: Decodable {
    var items: [User]
}
