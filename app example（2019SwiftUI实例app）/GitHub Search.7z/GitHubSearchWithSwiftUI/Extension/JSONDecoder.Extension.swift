//
//  JSONDecoder.Extension.swift
//  GitHubSearchWithSwiftUI
//
//  Created by marty-suzuki on 2019/06/06.
//  Copyright © 2019 jp.marty-suzuki. All rights reserved.
//

import Combine
import Foundation

// now in Foundation
//extension JSONDecoder: TopLevelDecoder {}
