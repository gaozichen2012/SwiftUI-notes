# SFSymbols-Playground
A playground listing all the SFSymbols in SwiftUI

![Demo GIF](https://github.com/jstart/SFSymbols-Playground/blob/master/demo.gif)

You can download the SF Symbols.app beta for Mac here: https://developer.apple.com/design/downloads/SF-Symbols.dmg
A Swift Package has already been developed to make SF Symbols an enum instead of strings: https://twitter.com/simjp/status/1135936933916336128
