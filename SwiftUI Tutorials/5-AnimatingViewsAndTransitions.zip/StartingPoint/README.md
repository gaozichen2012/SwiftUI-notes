# Drawing Animating Views and Transitions

Use this project to code along with the [Animating Views and Transitions](https://developer.apple.com/tutorials/swiftui/animating-views-and-transitions) tutorial.